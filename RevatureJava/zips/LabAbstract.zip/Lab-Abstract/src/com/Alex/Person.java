package com.Alex;

public abstract class Person {

    protected String name;

    public abstract String getName();

    public abstract void setName(String name);
}
