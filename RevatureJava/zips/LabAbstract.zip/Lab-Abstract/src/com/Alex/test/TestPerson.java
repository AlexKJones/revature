package com.Alex.test;

public class TestPerson {

    public static void main(String[] args) {
        Person adam = new Person();
    }
}
