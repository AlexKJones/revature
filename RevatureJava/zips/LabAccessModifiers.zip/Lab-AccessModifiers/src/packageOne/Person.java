package packageOne;

public class Person {
	public int age = 12;

}
