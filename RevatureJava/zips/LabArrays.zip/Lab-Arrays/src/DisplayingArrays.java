
public class DisplayingArrays {
	public static void main(String[] args) {
        int[] intArray = new int[3];
        intArray[0] = -5123;
        intArray[2] = 32;

        System.out.println(intArray[3]);
    }
}
