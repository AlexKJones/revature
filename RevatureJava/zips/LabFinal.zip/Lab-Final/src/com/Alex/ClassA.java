package com.Alex;

public class ClassA {

    public String greeting = "Hello";

    public final void someMethod(){
        System.out.println("Some method.");
    }
}
