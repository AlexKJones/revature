package model;

public class Troll {
	//empty class
}
