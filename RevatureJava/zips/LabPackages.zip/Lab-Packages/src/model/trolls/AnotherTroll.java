package model.trolls;

public class AnotherTroll {

}
