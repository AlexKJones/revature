package test;

import model.Troll;
import model.trolls.AnotherTroll;

public class TestTroll {
	public static void main(String[] args){
		Troll troll = new Troll();
		AnotherTroll anothertroll = new AnotherTroll();
    }
}
