let cel = prompt('enter a number of degrees Celsius to convert.')
let newCel = cel * 1.8
let far = (newCel + 32)
alert(cel + ' degrees Celsius is ' + far + ' degrees Farenheit')