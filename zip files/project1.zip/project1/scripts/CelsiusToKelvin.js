let cel = prompt('enter a number of degrees Celsius to convert.')
let kel = (cel + 273.15)
alert(cel + ' degrees Celsius is ' + kel + ' degrees Kelvin')