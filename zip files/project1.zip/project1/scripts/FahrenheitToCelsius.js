let far = prompt('enter a number of degrees farenheit to convert.')
let cel = ((far - 32) * 0.5556)
alert(far + ' degrees Farenheit is ' + cel + ' degrees Celsius')