let far = prompt('enter a number of degrees farenheit to convert.')
let kel = (((far - 32) * 0.5556) + 273.15)
alert(far + ' degrees Farenheit is ' + kel + ' degrees Kelvin')